using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        OpenQA.Selenium.IWebDriver driver;
		IWebElement element;
		IList<IWebElement> elements;
		Actions actions;
		IJavaScriptExecutor javaScriptExecutor;
        [TestInitialize]
		public void setupInit()
		{
			var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
			var relativePath = @"..\chromedrivers\v96";
			var chromeDriverPath = Path.GetFullPath(Path.Combine(outPutDirectory, relativePath));
			driver = new ChromeDriver(chromeDriverPath);
			driver.Manage().Window.Maximize();
			driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
			driver.Navigate().GoToUrl("https://www.kayak.co.in/flights/");
			actions = new Actions(driver);
			javaScriptExecutor = (IJavaScriptExecutor)driver;
		}
		[DataTestMethod]
		[DataRow("MAA", "IXM")]
		[DataRow("MAA", "IXC")]
		[DataRow("MAA", "IXU")]
		[TestMethod]
        public void TestMethod1(String from,String to)
        {   
			elements = driver.FindElements(By.CssSelector("div[class='vvTc-item-close']"));
			foreach (IWebElement e in elements)
				e.Click();
			element = driver.FindElement(By.CssSelector("div[aria-label='Flight origin input']"));
			actions.MoveToElement(element).Click().Build().Perform();
			driver.FindElement(By.CssSelector(".k_my-input")).SendKeys(from);
			driver.FindElement(By.CssSelector("input[type='checkbox'][class='PVIO-input']")).Click();
			driver.FindElement(By.CssSelector(".cQtq-prefixIcon")).Click();
			Thread.Sleep(3000);
			driver.FindElement(By.XPath("//div[@role='button'][text()='10']")).Click();
			Thread.Sleep(3000);
			driver.FindElement(By.XPath("//div[@role='button'][text()='20']")).Click();
			Thread.Sleep(3000);
			element = driver.FindElement(By.XPath("//div[text()='To?']"));
			javaScriptExecutor.ExecuteScript("arguments[0].click()", element);
			driver.FindElement(By.CssSelector(".k_my-input")).SendKeys(to);
			driver.FindElement(By.CssSelector("input[type='checkbox'][class='PVIO-input']")).Click();
			driver.FindElement(By.CssSelector("button[aria-label='Search']")).Click();
            Thread.Sleep(6000);
			driver.FindElement(By.CssSelector("h3[id*='-price-title-text']")).Click();
			element = driver.FindElement(By.CssSelector("div[id*='-price-price-slider-sliderWidget-handle-0']"));
			javaScriptExecutor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
			javaScriptExecutor.ExecuteScript("arguments[0].setAttribute('style', 'left: 85%;')", element);
			Thread.Sleep(9000);
			int max = Convert.ToInt32(element.GetAttribute("aria-valuetext").Substring(2).Replace(",", ""));
			Console.WriteLine("Max Amount " + max);
			elements = driver.FindElements(By.XPath("//span[not(contains(@id,'extra-info')) and contains(@id,'price-text')]"));
			int locAmnt;
			foreach (IWebElement e in elements)
			{
				locAmnt = Convert.ToInt32(e.Text.Substring(2).Replace(",", ""));
				Console.WriteLine("Inline Amount " + locAmnt);
				Assert.IsTrue(locAmnt < max);
			}
        }
		[TestCleanup]
		public void Cleanup()
		{
			if (driver != null)
				driver.Quit();
		}
	}
}